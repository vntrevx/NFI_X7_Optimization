"""Optional position-risk controls for local TestX7 tuning experiments."""

from __future__ import annotations

import logging


log = logging.getLogger(__name__)
_TRUE_VALUES = {"1", "true", "yes", "on"}


class TestX7PositionRiskTuningMixin:
  """Keep upstream position adjustment behavior by default."""

  test_x7_long_grind_entry_depth_cap = 0
  test_x7_long_grind_entry_depth_pair_caps = {}
  test_x7_position_entry_depth_pair_caps = {}
  test_x7_position_entry_depth_tag_caps = {}
  test_x7_position_entry_depth_pair_tag_caps = {}
  test_x7_disable_long_entries = False
  test_x7_short_entry_depth_cap = 0
  test_x7_short_entry_depth_pair_caps = {}
  test_x7_short_entry_depth_tag_caps = {}
  test_x7_short_entry_depth_pair_tag_caps = {}
  test_x7_disable_short_entries = False

  def _test_x7_positive_position_adjustment(self, result) -> bool:
    if result is None:
      return False

    amount = result[0] if isinstance(result, tuple) and result else result
    if isinstance(amount, bool) or not isinstance(amount, (int, float)):
      return False

    return amount > 0

  def _test_x7_valid_entry_depth_cap(self, value) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
      return 0

    cap = int(value)
    return cap if cap > 0 else 0

  def _test_x7_bool_flag(self, value) -> bool:
    if isinstance(value, str):
      return value.strip().lower() in _TRUE_VALUES
    return bool(value)

  def _test_x7_positive_adjustment_disabled(self, trade) -> bool:
    if getattr(trade, "is_short", False):
      return self._test_x7_bool_flag(self.test_x7_disable_short_entries)
    return self._test_x7_bool_flag(self.test_x7_disable_long_entries)

  def _test_x7_entry_depth_cap_from_pair_caps(self, pair_caps, pair: str) -> int:
    if isinstance(pair_caps, dict):
      base_pair = pair.split("/")[0]
      for pair_key in (pair, base_pair):
        cap = self._test_x7_valid_entry_depth_cap(pair_caps.get(pair_key))
        if cap > 0:
          return cap

    return 0

  def _test_x7_trade_entry_tags(self, trade) -> set[str]:
    return {tag for tag in str(getattr(trade, "enter_tag", "") or "").split() if tag}

  def _test_x7_entry_depth_cap_from_tag_caps(self, tag_caps, tags: set[str]) -> int:
    if not isinstance(tag_caps, dict):
      return 0

    caps = [
      self._test_x7_valid_entry_depth_cap(tag_caps.get(tag))
      for tag in tags
    ]
    caps = [cap for cap in caps if cap > 0]
    return min(caps) if caps else 0

  def _test_x7_entry_depth_cap_from_pair_tag_caps(self, pair_tag_caps, pair: str, tags: set[str]) -> int:
    if not isinstance(pair_tag_caps, dict):
      return 0

    base_pair = pair.split("/")[0]
    for pair_key in (pair, base_pair):
      tag_caps = pair_tag_caps.get(pair_key)
      cap = self._test_x7_entry_depth_cap_from_tag_caps(tag_caps, tags)
      if cap > 0:
        return cap

    return 0

  def _test_x7_long_grind_entry_depth_cap_for_pair(self, pair: str) -> int:
    cap = self._test_x7_entry_depth_cap_from_pair_caps(
      self.test_x7_long_grind_entry_depth_pair_caps,
      pair,
    )
    if cap > 0:
      return cap

    return self._test_x7_valid_entry_depth_cap(self.test_x7_long_grind_entry_depth_cap)

  def _test_x7_position_entry_depth_cap_for_pair(self, pair: str) -> int:
    return self._test_x7_entry_depth_cap_from_pair_caps(
      self.test_x7_position_entry_depth_pair_caps,
      pair,
    )

  def _test_x7_position_entry_depth_cap_for_trade(self, trade) -> int:
    tags = self._test_x7_trade_entry_tags(trade)
    pair = getattr(trade, "pair", "")
    cap = self._test_x7_entry_depth_cap_from_pair_tag_caps(
      self.test_x7_position_entry_depth_pair_tag_caps,
      pair,
      tags,
    )
    if cap > 0:
      return cap

    cap = self._test_x7_entry_depth_cap_from_tag_caps(
      self.test_x7_position_entry_depth_tag_caps,
      tags,
    )
    if cap > 0:
      return cap

    return self._test_x7_position_entry_depth_cap_for_pair(pair)

  def _test_x7_short_entry_depth_cap_for_pair(self, pair: str) -> int:
    cap = self._test_x7_entry_depth_cap_from_pair_caps(
      self.test_x7_short_entry_depth_pair_caps,
      pair,
    )
    if cap > 0:
      return cap

    return self._test_x7_valid_entry_depth_cap(self.test_x7_short_entry_depth_cap)

  def _test_x7_short_entry_depth_cap_for_trade(self, trade) -> int:
    tags = self._test_x7_trade_entry_tags(trade)
    pair = getattr(trade, "pair", "")
    cap = self._test_x7_entry_depth_cap_from_pair_tag_caps(
      self.test_x7_short_entry_depth_pair_tag_caps,
      pair,
      tags,
    )
    if cap > 0:
      return cap

    cap = self._test_x7_entry_depth_cap_from_tag_caps(
      self.test_x7_short_entry_depth_tag_caps,
      tags,
    )
    if cap > 0:
      return cap

    return self._test_x7_short_entry_depth_cap_for_pair(pair)

  def _test_x7_is_long_grind_trade(self, trade) -> bool:
    if getattr(trade, "is_short", False):
      return False

    enter_tag = getattr(trade, "enter_tag", None)
    if enter_tag is None:
      return False

    enter_tags = str(enter_tag).split()
    return all(tag in enter_tags for tag in self.long_grind_mode_tags)

  def _test_x7_should_block_long_grind_position_entry(self, trade, result) -> bool:
    if not self._test_x7_positive_position_adjustment(result):
      return False

    if not self._test_x7_is_long_grind_trade(trade):
      return False

    cap = self._test_x7_long_grind_entry_depth_cap_for_pair(getattr(trade, "pair", ""))
    if cap <= 0:
      return False

    entries = getattr(trade, "nr_of_successful_entries", None)
    if isinstance(entries, bool) or not isinstance(entries, int):
      return False

    return entries >= cap

  def _test_x7_should_block_pair_position_entry(self, trade, result) -> bool:
    if not self._test_x7_positive_position_adjustment(result):
      return False

    if getattr(trade, "is_short", False):
      return False

    cap = self._test_x7_position_entry_depth_cap_for_trade(trade)
    if cap <= 0:
      return False

    entries = getattr(trade, "nr_of_successful_entries", None)
    if isinstance(entries, bool) or not isinstance(entries, int):
      return False

    return entries >= cap

  def _test_x7_should_block_short_position_entry(self, trade, result) -> bool:
    if not self._test_x7_positive_position_adjustment(result):
      return False

    if not getattr(trade, "is_short", False):
      return False

    cap = self._test_x7_short_entry_depth_cap_for_trade(trade)
    if cap <= 0:
      return False

    entries = getattr(trade, "nr_of_successful_entries", None)
    if isinstance(entries, bool) or not isinstance(entries, int):
      return False

    return entries >= cap

  def adjust_trade_position(self, trade, *args, **kwargs):
    result = super().adjust_trade_position(trade, *args, **kwargs)
    if self._test_x7_positive_position_adjustment(result) and self._test_x7_positive_adjustment_disabled(trade):
      log.warning(
        "Blocking position entry for %s because the TestX7 position kill switch is enabled.",
        getattr(trade, "pair", "?"),
      )
      return None

    if self._test_x7_should_block_pair_position_entry(trade, result):
      log.info(
        "Blocking position entry for %s because entry depth %s reached cap %s.",
        getattr(trade, "pair", "?"),
        getattr(trade, "nr_of_successful_entries", "?"),
        self._test_x7_position_entry_depth_cap_for_trade(trade),
      )
      return None

    if self._test_x7_should_block_short_position_entry(trade, result):
      log.info(
        "Blocking short position entry for %s because entry depth %s reached cap %s.",
        getattr(trade, "pair", "?"),
        getattr(trade, "nr_of_successful_entries", "?"),
        self._test_x7_short_entry_depth_cap_for_trade(trade),
      )
      return None

    if self._test_x7_should_block_long_grind_position_entry(trade, result):
      log.info(
        "Blocking long grind entry for %s because entry depth %s reached cap %s.",
        getattr(trade, "pair", "?"),
        getattr(trade, "nr_of_successful_entries", "?"),
        self._test_x7_long_grind_entry_depth_cap_for_pair(getattr(trade, "pair", "")),
      )
      return None

    return result
