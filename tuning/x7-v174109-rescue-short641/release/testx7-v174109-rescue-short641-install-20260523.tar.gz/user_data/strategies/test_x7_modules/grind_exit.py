"""Configurable grind-exit experiments for the local TestX7 strategy."""

from __future__ import annotations


class TestX7GrindExitTuningMixin:
  """Keep upstream grind exits by default, with optional pair thresholds."""

  test_x7_long_grind_exit_profit_threshold = 0.25
  test_x7_long_grind_exit_pair_thresholds = {}
  test_x7_long_grind_age_exit_pair_rules = {}

  def _test_x7_pair_rule(self, pair: str, rules):
    if not isinstance(rules, dict):
      return None

    base_pair = pair.split("/")[0]
    for pair_key in (pair, base_pair):
      rule = rules.get(pair_key)
      if isinstance(rule, dict):
        return rule

    return None

  def _test_x7_number_from_rule(self, rule: dict, key: str):
    value = rule.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
      return None
    return float(value)

  def _test_x7_trade_age_days(self, trade, current_time):
    open_time = getattr(trade, "open_date_utc", None)
    if open_time is None or current_time is None:
      return None

    if getattr(open_time, "tzinfo", None) is not None and getattr(current_time, "tzinfo", None) is None:
      open_time = open_time.replace(tzinfo=None)
    elif getattr(open_time, "tzinfo", None) is None and getattr(current_time, "tzinfo", None) is not None:
      current_time = current_time.replace(tzinfo=None)

    return (current_time - open_time).total_seconds() / 86400.0

  def _test_x7_long_grind_age_exit_rule_for_pair(self, pair: str):
    return self._test_x7_pair_rule(pair, self.test_x7_long_grind_age_exit_pair_rules)

  def _test_x7_should_age_exit_long_grind(self, pair: str, trade, current_time, profit_init_ratio: float) -> bool:
    rule = self._test_x7_long_grind_age_exit_rule_for_pair(pair)
    if rule is None:
      return False

    min_age_days = self._test_x7_number_from_rule(rule, "min_age_days")
    min_profit = self._test_x7_number_from_rule(rule, "min_profit")
    if min_age_days is None or min_profit is None:
      return False

    age_days = self._test_x7_trade_age_days(trade, current_time)
    if age_days is None:
      return False

    return age_days >= min_age_days and profit_init_ratio > min_profit

  def test_x7_long_grind_exit_threshold_for_pair(self, pair):
    pair_thresholds = self.test_x7_long_grind_exit_pair_thresholds
    if isinstance(pair_thresholds, dict) and pair in pair_thresholds:
      return pair_thresholds[pair]

    return self.test_x7_long_grind_exit_profit_threshold

  def long_exit_grind(
    self,
    pair,
    current_rate,
    profit_stake,
    profit_ratio,
    profit_current_stake_ratio,
    profit_init_ratio,
    max_profit,
    max_loss,
    filled_entries,
    filled_exits,
    last_candle,
    previous_candle_1,
    previous_candle_2,
    previous_candle_3,
    previous_candle_4,
    previous_candle_5,
    trade,
    current_time,
    enter_tags,
  ):
    threshold = self.test_x7_long_grind_exit_threshold_for_pair(pair)
    if profit_init_ratio > threshold:
      return True, f"exit_{self.long_grind_mode_name}_g"

    if self._test_x7_should_age_exit_long_grind(pair, trade, current_time, profit_init_ratio):
      return True, f"exit_{self.long_grind_mode_name}_age"

    return False, None
