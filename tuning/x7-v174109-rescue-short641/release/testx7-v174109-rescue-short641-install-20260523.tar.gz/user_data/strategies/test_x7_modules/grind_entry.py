"""Configurable grind-entry slot experiments for the local TestX7 strategy."""

from __future__ import annotations

import logging

from freqtrade.persistence import Trade


log = logging.getLogger(__name__)


class TestX7GrindEntryTuningMixin:
  """Keep upstream grind slot behavior by default, with optional extra slots."""

  test_x7_grind_mode_extra_slot_pairs = []
  test_x7_grind_mode_extra_slots = 0
  test_x7_grind_entry_extra_slot_pairs = []
  test_x7_grind_entry_extra_slots = 0

  def _test_x7_string_list(self, value) -> set[str]:
    pairs = value
    if not isinstance(pairs, list):
      return set()
    return {pair for pair in pairs if isinstance(pair, str)}

  def _test_x7_extra_slot_pair_names(self) -> set[str]:
    return self._test_x7_string_list(self.test_x7_grind_mode_extra_slot_pairs)

  def _test_x7_entry_extra_slot_pair_names(self) -> set[str]:
    return self._test_x7_string_list(self.test_x7_grind_entry_extra_slot_pairs)

  def _test_x7_pair_uses_extra_grind_slot(self, pair: str, extra_slot_pairs: set[str]) -> bool:
    base_pair = pair.split("/")[0]
    return pair in extra_slot_pairs or base_pair in extra_slot_pairs

  def _test_x7_open_grind_trades(self, tags: list[str]):
    open_trades = Trade.get_trades_proxy(is_open=True)
    return [
      trade
      for trade in open_trades
      if getattr(trade, "enter_tag", None) is not None and all(tag in trade.enter_tag.split() for tag in tags)
    ]

  def _test_x7_can_use_named_extra_slot(self, pair: str, open_grind_trades, extra_slot_pairs: set[str], extra_slots) -> bool:
    if not isinstance(extra_slots, int) or extra_slots <= 0:
      return False

    if not self._test_x7_pair_uses_extra_grind_slot(pair, extra_slot_pairs):
      return False

    used_extra_slots = sum(
      1
      for trade in open_grind_trades
      if self._test_x7_pair_uses_extra_grind_slot(getattr(trade, "pair", ""), extra_slot_pairs)
    )
    return used_extra_slots < extra_slots

  def _test_x7_can_use_extra_grind_slot(self, pair: str, open_grind_trades) -> bool:
    return self._test_x7_can_use_named_extra_slot(
      pair,
      open_grind_trades,
      self._test_x7_extra_slot_pair_names(),
      self.test_x7_grind_mode_extra_slots,
    )

  def _test_x7_can_use_entry_extra_grind_slot(self, pair: str, open_grind_trades) -> bool:
    return self._test_x7_can_use_named_extra_slot(
      pair,
      open_grind_trades,
      self._test_x7_entry_extra_slot_pair_names(),
      self.test_x7_grind_entry_extra_slots,
    )

  def _test_x7_can_open_long_grind_entry(self, pair: str, open_grind_count: int) -> bool:
    if open_grind_count < self.grind_mode_max_slots:
      return True

    open_grind_trades = self._test_x7_open_grind_trades(self.long_grind_mode_tags)
    return (
      self._test_x7_can_use_extra_grind_slot(pair, open_grind_trades)
      or self._test_x7_can_use_entry_extra_grind_slot(pair, open_grind_trades)
    )

  def _handle_grind_mode(self, pair: str, config: dict, current_time) -> bool:
    is_pair_grind_mode = pair.split("/")[0] in config["coins"]
    if not is_pair_grind_mode:
      log.info(f"[{current_time}] Cancelling entry for {pair} due to not being in grind mode coins list.")
      return False

    open_grind_trades = self._test_x7_open_grind_trades(config["tags"])
    if len(open_grind_trades) < config["max_slots"]:
      return True

    if self._test_x7_can_use_extra_grind_slot(pair, open_grind_trades):
      return True

    if self._test_x7_can_use_entry_extra_grind_slot(pair, open_grind_trades):
      return True

    log.info(f"[{current_time}] Cancelling entry for {pair} due to grind mode slots limit reached.")
    return False
