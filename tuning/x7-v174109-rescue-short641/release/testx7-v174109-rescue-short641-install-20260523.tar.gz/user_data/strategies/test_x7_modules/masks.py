"""Reusable boolean mask helpers for TestX7 vectorized logic."""

from __future__ import annotations

import numpy as np
from pandas import DataFrame, isna as pd_isna


def build_comparison_cache(df: DataFrame):
  cache = {}

  def _cmp(column: str, op: str, value: float):
    key = (column, op, value)
    result = cache.get(key)
    if result is not None:
      return result

    values = df[column].to_numpy(copy=False)
    if op == ">":
      result = values > value
    elif op == ">=":
      result = values >= value
    elif op == "<":
      result = values < value
    elif op == "<=":
      result = values <= value
    else:
      raise ValueError(f"Unsupported comparison operator: {op}")

    cache[key] = result
    return result

  return _cmp


def build_expression_cache(df: DataFrame):
  cache = {}

  def _gt_mul(left_column: str, right_column: str, multiplier: float):
    key = ("gt_mul", left_column, right_column, float(multiplier))
    result = cache.get(key)
    if result is None:
      result = (df[left_column].to_numpy(copy=False) > (df[right_column].to_numpy(copy=False) * multiplier))
      cache[key] = result
    return result

  def _range_lt(high_column: str, low_column: str, value: float):
    key = ("range_lt", high_column, low_column, float(value))
    result = cache.get(key)
    if result is None:
      high = df[high_column].to_numpy(copy=False)
      low = df[low_column].to_numpy(copy=False)
      result = ((high - low) / low) < value
      cache[key] = result
    return result

  return _gt_mul, _range_lt


def build_diff_gt_mul_cache(df: DataFrame):
  cache = {}
  values_cache = {}

  def _values(column: str):
    result = values_cache.get(column)
    if result is None:
      result = df[column].to_numpy(copy=False)
      values_cache[column] = result
    return result

  def _shifted(column: str, periods: int):
    if periods == 0:
      return _values(column)

    key = ("shift", column, periods)
    result = cache.get(key)
    if result is not None:
      return result

    values = _values(column)
    result = np.empty(values.shape, dtype=np.float64)
    result[:] = np.nan
    if periods > 0 and len(values) > periods:
      result[periods:] = values[:-periods]
    elif periods < 0 and len(values) > abs(periods):
      result[:periods] = values[-periods:]
    cache[key] = result
    return result

  def _diff_gt_mul(
    left_column: str,
    subtract_column: str,
    right_column: str,
    multiplier: float,
    periods: int = 0,
  ):
    key = ("diff_gt_mul", left_column, subtract_column, right_column, float(multiplier), periods)
    result = cache.get(key)
    if result is None:
      result = (
        (_shifted(left_column, periods) - _shifted(subtract_column, periods))
        > (_values(right_column) * multiplier)
      )
      cache[key] = result
    return result

  return _diff_gt_mul


def build_lt_mul_cache(df: DataFrame):
  cache = {}
  values_cache = {}

  def _values(column: str):
    result = values_cache.get(column)
    if result is None:
      result = df[column].to_numpy(copy=False)
      values_cache[column] = result
    return result

  def _lt_mul(left_column: str, right_column: str, multiplier: float):
    key = ("lt_mul", left_column, right_column, float(multiplier))
    result = cache.get(key)
    if result is None:
      result = _values(left_column) < (_values(right_column) * multiplier)
      cache[key] = result
    return result

  return _lt_mul


def build_mul_comparison_cache(df: DataFrame):
  cache = {}
  values_cache = {}

  def _values(column: str):
    result = values_cache.get(column)
    if result is None:
      result = df[column].to_numpy(copy=False)
      values_cache[column] = result
    return result

  def _mul_cmp(left_column: str, op: str, right_column: str, multiplier: float):
    key = ("mul_cmp", left_column, op, right_column, float(multiplier))
    result = cache.get(key)
    if result is not None:
      return result

    left = _values(left_column)
    right = _values(right_column) * multiplier
    if op == ">":
      result = left > right
    elif op == ">=":
      result = left >= right
    elif op == "<":
      result = left < right
    elif op == "<=":
      result = left <= right
    else:
      raise ValueError(f"Unsupported comparison operator: {op}")
    cache[key] = result
    return result

  return _mul_cmp


def build_column_comparison_cache(df: DataFrame):
  cache = {}
  values_cache = {}

  def _values(column: str):
    result = values_cache.get(column)
    if result is None:
      result = df[column].to_numpy(copy=False)
      values_cache[column] = result
    return result

  def _shifted(column: str, periods: int):
    if periods == 0:
      return _values(column)

    key = ("shift", column, periods)
    result = cache.get(key)
    if result is not None:
      return result

    values = _values(column)
    result = np.empty(values.shape, dtype=np.float64)
    result[:] = np.nan
    if periods > 0 and len(values) > periods:
      result[periods:] = values[:-periods]
    elif periods < 0 and len(values) > abs(periods):
      result[:periods] = values[-periods:]
    cache[key] = result
    return result

  def _compare(left, op: str, right):
    if op == ">":
      return left > right
    if op == ">=":
      return left >= right
    if op == "<":
      return left < right
    if op == "<=":
      return left <= right
    raise ValueError(f"Unsupported comparison operator: {op}")

  def _col_cmp(left_column: str, op: str, right_column: str):
    key = ("col_cmp", left_column, op, right_column)
    result = cache.get(key)
    if result is None:
      result = _compare(_values(left_column), op, _values(right_column))
      cache[key] = result
    return result

  def _shift_col_cmp(left_column: str, op: str, right_column: str, periods: int):
    key = ("shift_col_cmp", left_column, op, right_column, periods)
    result = cache.get(key)
    if result is None:
      result = _compare(_values(left_column), op, _shifted(right_column, periods))
      cache[key] = result
    return result

  def _shift_pair_cmp(left_column: str, left_periods: int, op: str, right_column: str, right_periods: int):
    key = ("shift_pair_cmp", left_column, left_periods, op, right_column, right_periods)
    result = cache.get(key)
    if result is None:
      result = _compare(_shifted(left_column, left_periods), op, _shifted(right_column, right_periods))
      cache[key] = result
    return result

  def _notna(column: str):
    key = ("notna", column)
    result = cache.get(key)
    if result is None:
      result = ~pd_isna(_values(column))
      cache[key] = result
    return result

  def _shift_notna(column: str, periods: int):
    key = ("shift_notna", column, periods)
    result = cache.get(key)
    if result is None:
      result = ~pd_isna(_shifted(column, periods))
      cache[key] = result
    return result

  return _col_cmp, _shift_col_cmp, _shift_pair_cmp, _notna, _shift_notna


def build_shift_comparison_cache(df: DataFrame):
  cache = {}
  values_cache = {}

  def _values(column: str):
    result = values_cache.get(column)
    if result is None:
      result = df[column].to_numpy(copy=False)
      values_cache[column] = result
    return result

  def _shifted(column: str, periods: int):
    key = ("shift", column, periods)
    result = cache.get(key)
    if result is not None:
      return result

    values = _values(column)
    result = np.empty(values.shape, dtype=np.float64)
    result[:] = np.nan
    if periods > 0 and len(values) > periods:
      result[periods:] = values[:-periods]
    elif periods == 0:
      result[:] = values
    elif periods < 0 and len(values) > abs(periods):
      result[:periods] = values[-periods:]
    cache[key] = result
    return result

  def _shift_cmp(column: str, periods: int, op: str, value: float):
    key = ("shift_cmp", column, periods, op, float(value))
    result = cache.get(key)
    if result is not None:
      return result

    values = _shifted(column, periods)
    if op == ">":
      result = values > value
    elif op == ">=":
      result = values >= value
    elif op == "<":
      result = values < value
    elif op == "<=":
      result = values <= value
    else:
      raise ValueError(f"Unsupported comparison operator: {op}")
    cache[key] = result
    return result

  return _shift_cmp
