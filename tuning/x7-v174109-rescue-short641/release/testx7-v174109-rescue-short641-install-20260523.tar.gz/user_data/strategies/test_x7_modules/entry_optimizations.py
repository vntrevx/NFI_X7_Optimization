"""Behavior-gated entry optimizations for TestX7."""

from __future__ import annotations

import logging
import os
from typing import Any

_FALSE_VALUES = {"0", "false", "no", "off"}
_TRUE_VALUES = {"1", "true", "yes", "on"}

log = logging.getLogger(__name__)


def _disabled_from_env(name: str) -> bool:
  return os.getenv(name, "").strip().lower() in _FALSE_VALUES


class TestX7EntryOptimizationMixin:
  test_x7_skip_spot_short_entry_calc_env = "TEST_X7_SKIP_SPOT_SHORT_ENTRY_CALC"
  test_x7_entry_tail_rows_env = "TEST_X7_ENTRY_TAIL_ROWS"
  test_x7_entry_return_tail_env = "TEST_X7_ENTRY_RETURN_TAIL"
  test_x7_block_long_entry_pair_tags = {}
  test_x7_block_short_entry_pair_tags = {}
  test_x7_long_entry_crash_guard_rules = {}
  test_x7_disable_long_entries = False
  test_x7_disable_short_entries = False

  def _test_x7_skip_spot_short_entry_calc_enabled(self) -> bool:
    config = getattr(self, "config", {})
    config_value = config.get("test_x7_skip_spot_short_entry_calc", True)
    return bool(config_value) and not _disabled_from_env(self.test_x7_skip_spot_short_entry_calc_env)

  def _test_x7_trading_mode_value(self) -> str:
    trading_mode: Any = getattr(self, "config", {}).get("trading_mode", "")
    return str(getattr(trading_mode, "value", trading_mode)).lower()

  def _test_x7_should_skip_short_entry_calc(self) -> bool:
    return (
      self._test_x7_skip_spot_short_entry_calc_enabled()
      and self._test_x7_trading_mode_value() == "spot"
      and not bool(getattr(self, "can_short", False))
    )

  def _test_x7_entry_tail_rows(self) -> int:
    env_value = os.getenv(self.test_x7_entry_tail_rows_env)
    config = getattr(self, "config", {})
    config_value = config.get("test_x7_entry_tail_rows", 0)
    try:
      rows = int(env_value if env_value is not None else config_value)
    except (TypeError, ValueError):
      return 0
    return max(0, rows)

  def _test_x7_entry_return_tail_enabled(self) -> bool:
    env_value = os.getenv(self.test_x7_entry_return_tail_env)
    if env_value is not None:
      return env_value.strip().lower() in _TRUE_VALUES
    return bool(getattr(self, "config", {}).get("test_x7_entry_return_tail", False))

  def _test_x7_entry_backtest_like_runmode(self) -> bool:
    checker = getattr(self, "_test_x7_is_backtest_like_runmode", None)
    if callable(checker):
      return bool(checker())
    runmode = getattr(getattr(self, "dp", None), "runmode", None)
    value = str(getattr(runmode, "value", runmode))
    return value in {"backtest", "hyperopt", "plot", "webserver"}

  def _test_x7_populate_entry_trend_tail(self, dataframe, metadata: dict):
    rows = self._test_x7_entry_tail_rows()
    if rows <= 0 or len(dataframe) <= rows:
      return super().populate_entry_trend(dataframe, metadata)

    tail = dataframe.tail(rows).copy(deep=False)
    tail = super().populate_entry_trend(tail, metadata)
    if self._test_x7_entry_return_tail_enabled() and not self._test_x7_entry_backtest_like_runmode():
      return tail

    if "enter_long" not in dataframe:
      dataframe.loc[:, "enter_long"] = 0
    if "enter_short" not in dataframe:
      dataframe.loc[:, "enter_short"] = 0
    if "enter_tag" not in dataframe:
      dataframe.loc[:, "enter_tag"] = ""

    for column in ("enter_long", "enter_short", "enter_tag"):
      if column in tail:
        dataframe.loc[tail.index, column] = tail[column]
    return dataframe

  def _test_x7_string_set(self, values) -> set[str]:
    if isinstance(values, str):
      return {values.strip()} if values.strip() else set()

    if isinstance(values, (list, tuple, set)):
      return {str(value).strip() for value in values if str(value).strip()}

    return set()

  def _test_x7_bool_flag(self, value) -> bool:
    if isinstance(value, str):
      return value.strip().lower() in _TRUE_VALUES
    return bool(value)

  def _test_x7_float_or_none(self, value) -> float | None:
    try:
      return float(value)
    except (TypeError, ValueError):
      return None

  def _test_x7_percent_drop(self, open_rate, close_rate) -> float:
    open_value = self._test_x7_float_or_none(open_rate)
    close_value = self._test_x7_float_or_none(close_rate)
    if open_value is None or close_value is None or open_value <= 0.0:
      return 0.0
    return max(0.0, ((open_value - close_value) / open_value) * 100.0)

  def _test_x7_percent_range(self, open_rate, high_rate, low_rate) -> float:
    open_value = self._test_x7_float_or_none(open_rate)
    high_value = self._test_x7_float_or_none(high_rate)
    low_value = self._test_x7_float_or_none(low_rate)
    if open_value is None or high_value is None or low_value is None or open_value <= 0.0:
      return 0.0
    return max(0.0, ((high_value - low_value) / open_value) * 100.0)

  def _test_x7_crash_guard_blocks(self, rule, open_rate, high_rate, low_rate, close_rate) -> bool:
    if not isinstance(rule, dict):
      return False

    max_drop = self._test_x7_float_or_none(rule.get("max_candle_drop_pct"))
    if max_drop is not None and self._test_x7_percent_drop(open_rate, close_rate) >= max_drop:
      return True

    max_range = self._test_x7_float_or_none(rule.get("max_candle_range_pct"))
    if max_range is not None and self._test_x7_percent_range(open_rate, high_rate, low_rate) >= max_range:
      return True

    return False

  def _test_x7_apply_long_entry_crash_guard(self, dataframe):
    rules = self.test_x7_long_entry_crash_guard_rules
    if not isinstance(rules, dict) or not rules:
      return dataframe
    required_columns = {"enter_long", "enter_tag", "open", "close"}
    if any(column not in dataframe for column in required_columns):
      return dataframe

    high_values = dataframe["high"].to_list() if "high" in dataframe else [None] * len(dataframe)
    low_values = dataframe["low"].to_list() if "low" in dataframe else [None] * len(dataframe)
    short_values = dataframe["enter_short"].to_list() if "enter_short" in dataframe else [0] * len(dataframe)
    entry_values = []
    enter_tag_values = []
    changed = False

    rows = zip(
      dataframe["enter_long"].to_list(),
      dataframe["enter_tag"].to_list(),
      short_values,
      dataframe["open"].to_list(),
      high_values,
      low_values,
      dataframe["close"].to_list(),
    )
    for should_enter, enter_tag, short_entry, open_rate, high_rate, low_rate, close_rate in rows:
      tags = str(enter_tag or "").split()
      if not bool(should_enter) or bool(short_entry) or not tags:
        entry_values.append(should_enter)
        enter_tag_values.append(enter_tag)
        continue

      remaining_tags = [
        tag
        for tag in tags
        if not self._test_x7_crash_guard_blocks(
          rules.get(tag),
          open_rate,
          high_rate,
          low_rate,
          close_rate,
        )
      ]
      if len(remaining_tags) == len(tags):
        entry_values.append(should_enter)
        enter_tag_values.append(enter_tag)
        continue

      enter_tag_values.append((" ".join(remaining_tags) + " ") if remaining_tags else "")
      entry_values.append(1 if remaining_tags else 0)
      changed = True

    if changed:
      dataframe.loc[:, "enter_long"] = entry_values
      dataframe.loc[:, "enter_tag"] = enter_tag_values

    return dataframe

  def _test_x7_blocked_entry_tags_for_pair(self, pair_tags, pair: str) -> set[str]:
    if not isinstance(pair_tags, dict):
      return set()

    base_pair = pair.split("/")[0]
    blocked_tags = set()
    for pair_key in (pair, base_pair):
      blocked_tags.update(self._test_x7_string_set(pair_tags.get(pair_key)))

    return blocked_tags

  def _test_x7_blocked_long_entry_tags_for_pair(self, pair: str) -> set[str]:
    return self._test_x7_blocked_entry_tags_for_pair(self.test_x7_block_long_entry_pair_tags, pair)

  def _test_x7_blocked_short_entry_tags_for_pair(self, pair: str) -> set[str]:
    return self._test_x7_blocked_entry_tags_for_pair(self.test_x7_block_short_entry_pair_tags, pair)

  def _test_x7_apply_blocked_entry_pair_tags(self, dataframe, metadata: dict, entry_column: str, pair_tags):
    blocked_tags = self._test_x7_blocked_entry_tags_for_pair(pair_tags, metadata.get("pair", ""))
    if not blocked_tags or entry_column not in dataframe or "enter_tag" not in dataframe:
      return dataframe

    entry_values = []
    enter_tag_values = []
    changed = False

    for should_enter, enter_tag in zip(dataframe[entry_column].to_list(), dataframe["enter_tag"].to_list()):
      tags = str(enter_tag or "").split()
      if not bool(should_enter) or not tags or not blocked_tags.intersection(tags):
        entry_values.append(should_enter)
        enter_tag_values.append(enter_tag)
        continue

      remaining_tags = [tag for tag in tags if tag not in blocked_tags]
      enter_tag_values.append((" ".join(remaining_tags) + " ") if remaining_tags else "")
      entry_values.append(1 if remaining_tags else 0)
      changed = True

    if changed:
      dataframe.loc[:, entry_column] = entry_values
      dataframe.loc[:, "enter_tag"] = enter_tag_values

    return dataframe

  def _test_x7_apply_blocked_long_entry_pair_tags(self, dataframe, metadata: dict):
    return self._test_x7_apply_blocked_entry_pair_tags(
      dataframe,
      metadata,
      "enter_long",
      self.test_x7_block_long_entry_pair_tags,
    )

  def _test_x7_apply_blocked_short_entry_pair_tags(self, dataframe, metadata: dict):
    return self._test_x7_apply_blocked_entry_pair_tags(
      dataframe,
      metadata,
      "enter_short",
      self.test_x7_block_short_entry_pair_tags,
    )

  def _test_x7_entry_params_without_blocked_tags(self, params, blocked_tags: set[str], side: str):
    if not params or not blocked_tags:
      return params

    next_params = None
    for tag in blocked_tags:
      key = f"{side}_entry_condition_{tag}_enable"
      if params.get(key):
        if next_params is None:
          next_params = dict(params)
        next_params[key] = False

    return next_params if next_params is not None else params

  def _test_x7_apply_entry_kill_switch(self, dataframe):
    disable_long = self._test_x7_bool_flag(self.test_x7_disable_long_entries)
    disable_short = self._test_x7_bool_flag(self.test_x7_disable_short_entries)
    if not disable_long and not disable_short:
      return dataframe

    has_long = "enter_long" in dataframe
    has_short = "enter_short" in dataframe
    if not has_long and not has_short:
      return dataframe

    row_count = len(dataframe)
    long_values = dataframe["enter_long"].to_list() if has_long else [0] * row_count
    short_values = dataframe["enter_short"].to_list() if has_short else [0] * row_count
    tag_values = dataframe["enter_tag"].to_list() if "enter_tag" in dataframe else ["" for _ in range(row_count)]

    next_long_values = []
    next_short_values = []
    next_tag_values = []
    changed = False

    for long_entry, short_entry, enter_tag in zip(long_values, short_values, tag_values):
      next_long = 0 if disable_long and bool(long_entry) else long_entry
      next_short = 0 if disable_short and bool(short_entry) else short_entry
      next_tag = enter_tag if bool(next_long) or bool(next_short) else ""

      next_long_values.append(next_long)
      next_short_values.append(next_short)
      next_tag_values.append(next_tag)
      changed = changed or next_long != long_entry or next_short != short_entry or next_tag != enter_tag

    if changed:
      if has_long:
        dataframe.loc[:, "enter_long"] = next_long_values
      if has_short:
        dataframe.loc[:, "enter_short"] = next_short_values
      if "enter_tag" in dataframe:
        dataframe.loc[:, "enter_tag"] = next_tag_values

    return dataframe

  def _test_x7_entry_side_disabled(self, side: str) -> bool:
    side_value = str(side or "").lower()
    if side_value == "short":
      return self._test_x7_bool_flag(self.test_x7_disable_short_entries)
    return self._test_x7_bool_flag(self.test_x7_disable_long_entries)

  def confirm_trade_entry(
    self,
    pair: str,
    order_type: str,
    amount: float,
    rate: float,
    time_in_force: str,
    current_time,
    entry_tag,
    side: str,
    **kwargs,
  ) -> bool:
    if self._test_x7_entry_side_disabled(side):
      log.warning("Blocking %s entry for %s because the TestX7 entry kill switch is enabled.", side, pair)
      return False

    return super().confirm_trade_entry(
      pair,
      order_type,
      amount,
      rate,
      time_in_force,
      current_time,
      entry_tag,
      side,
      **kwargs,
    )

  def _test_x7_apply_blocked_entry_pair_tags_for_sides(self, dataframe, metadata: dict):
    dataframe = self._test_x7_apply_blocked_long_entry_pair_tags(dataframe, metadata)
    dataframe = self._test_x7_apply_long_entry_crash_guard(dataframe)
    dataframe = self._test_x7_apply_blocked_short_entry_pair_tags(dataframe, metadata)
    return self._test_x7_apply_entry_kill_switch(dataframe)

  def populate_entry_trend(self, dataframe, metadata: dict):
    pair = metadata.get("pair", "")
    original_long_params = getattr(self, "long_entry_signal_params", None)
    original_short_params = getattr(self, "short_entry_signal_params", None)

    long_params = self._test_x7_entry_params_without_blocked_tags(
      original_long_params,
      self._test_x7_blocked_long_entry_tags_for_pair(pair),
      "long",
    )
    if original_long_params is not long_params:
      self.long_entry_signal_params = long_params

    short_params = original_short_params
    if self._test_x7_should_skip_short_entry_calc() and original_short_params:
      short_params = {key: False for key in original_short_params}
    else:
      short_params = self._test_x7_entry_params_without_blocked_tags(
        original_short_params,
        self._test_x7_blocked_short_entry_tags_for_pair(pair),
        "short",
      )
    if original_short_params is not short_params:
      self.short_entry_signal_params = short_params

    try:
      dataframe = self._test_x7_populate_entry_trend_tail(dataframe, metadata)
      return self._test_x7_apply_blocked_entry_pair_tags_for_sides(dataframe, metadata)
    finally:
      if original_long_params is not long_params:
        self.long_entry_signal_params = original_long_params
      if original_short_params is not short_params:
        self.short_entry_signal_params = original_short_params
