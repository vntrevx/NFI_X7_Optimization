"""Fast informative-timeframe merge helpers for TestX7."""

from __future__ import annotations

import numpy as np
import pandas as pd
from freqtrade.exchange import timeframe_to_minutes
from pandas import DataFrame


def _datetime64_ns_values(series):
  if getattr(series.dtype, "kind", "") == "M":
    return series.to_numpy(dtype="datetime64[ns]", copy=False)
  return pd.to_datetime(series).to_numpy(dtype="datetime64[ns]")


def fast_merge_informative_pair(
  dataframe: DataFrame,
  informative: DataFrame,
  timeframe: str,
  timeframe_inf: str,
  ffill: bool = True,
  append_timeframe: bool = True,
  date_column: str = "date",
  suffix: str | None = None,
  drop_date_column: bool = False,
) -> DataFrame:
  """Merge informative data with Freqtrade's no-lookahead date shift.

  This is a TestX7-local replacement for Freqtrade's merge_ordered-based helper.
  It assumes sorted candle data, which is true for Freqtrade OHLCV data, and
  aligns the shifted informative rows with the base timeframe by searchsorted.
  """
  if not ffill:
    from freqtrade.strategy import merge_informative_pair

    return merge_informative_pair(
      dataframe,
      informative,
      timeframe,
      timeframe_inf,
      ffill=ffill,
      append_timeframe=append_timeframe,
      date_column=date_column,
      suffix=suffix,
    )

  if suffix and append_timeframe:
    raise ValueError("You can not specify `append_timeframe` as True and a `suffix`.")

  minutes_inf = timeframe_to_minutes(timeframe_inf)
  minutes = timeframe_to_minutes(timeframe)
  if minutes > minutes_inf:
    raise ValueError(
      "Tried to merge a faster timeframe to a slower timeframe."
      "This would create new rows, and can throw off your regular indicators."
    )

  if minutes == minutes_inf:
    date_merge_values = informative[date_column]
  elif timeframe_inf == "1M":
    date_merge_values = informative[date_column] + pd.offsets.MonthBegin(1) - pd.to_timedelta(minutes, "m")
  else:
    date_merge_values = informative[date_column] + pd.to_timedelta(minutes_inf - minutes, "m")

  date_merge = "date_merge"
  info = informative.copy(deep=False)
  info[date_merge] = date_merge_values

  if append_timeframe:
    date_merge = f"date_merge_{timeframe_inf}"
    info.columns = [f"{column}_{timeframe_inf}" for column in info.columns]
  elif suffix:
    date_merge = f"date_merge_{suffix}"
    info.columns = [f"{column}_{suffix}" for column in info.columns]

  drop_columns = [date_merge]
  if drop_date_column:
    if append_timeframe:
      drop_columns.append(f"{date_column}_{timeframe_inf}")
    elif suffix:
      drop_columns.append(f"{date_column}_{suffix}")
    else:
      drop_columns.append(date_column)

  if info.empty:
    aligned = info.drop(columns=drop_columns, errors="ignore")
    return pd.concat([dataframe.reset_index(drop=True), aligned], axis=1)

  merge_dates = info[date_merge]
  if not merge_dates.is_monotonic_increasing or not merge_dates.is_unique:
    info = info.sort_values(date_merge).drop_duplicates(date_merge, keep="last")
    merge_dates = info[date_merge]

  base_dates = _datetime64_ns_values(dataframe[date_column])
  informative_dates = _datetime64_ns_values(merge_dates)
  positions = np.searchsorted(informative_dates, base_dates, side="right") - 1
  valid = positions >= 0
  take_positions = positions.copy()
  if not valid.all():
    take_positions[~valid] = 0
  aligned = info.drop(columns=drop_columns, errors="ignore").iloc[take_positions].copy(deep=False)
  if not valid.all():
    aligned = aligned.copy()
    aligned.iloc[~valid, :] = np.nan
  aligned.index = dataframe.index

  return pd.concat([dataframe, aligned], axis=1)
